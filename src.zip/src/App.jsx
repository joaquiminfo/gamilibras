import React, { useState, useEffect } from 'react'
import { useGameState } from './useGameState'
import Home from './components/Home'
import Quiz from './components/Quiz'
import Profile from './components/Profile'
import BadgeToast from './components/BadgeToast'
import Confetti from './components/Confetti'

export default function App() {
  const gameState = useGameState()
  const [screen, setScreen] = useState('home') // 'home' | 'quiz' | 'profile'
  const [activeCategory, setActiveCategory] = useState(null)
  const [newBadges, setNewBadges] = useState([])
  const [showWelcome, setShowWelcome] = useState(false)

  // Show welcome on first visit
  useEffect(() => {
    if (gameState.totalLessons === 0 && gameState.totalXP === 0) {
      setShowWelcome(true)
      const t = setTimeout(() => setShowWelcome(false), 2500)
      return () => clearTimeout(t)
    }
  }, [])

  // Watch for new badges
  useEffect(() => {
    if (gameState._newBadges && gameState._newBadges.length > 0) {
      setNewBadges(gameState._newBadges)
    }
  }, [gameState._newBadges])

  function handleSelectCategory(catId) {
    if (gameState.hearts <= 0) {
      alert('Você ficou sem corações! Aguarde ou continue amanhã para recarregar. 💔')
      return
    }
    setActiveCategory(catId)
    setScreen('quiz')
  }

  function handleQuizFinish() {
    setScreen('home')
    setActiveCategory(null)
  }

  return (
    <>
      {/* Welcome splash */}
      {showWelcome && (
        <div style={{
          position:'fixed', inset:0, zIndex:9999,
          background:'linear-gradient(135deg, #0D0D1A, #1A1A2E)',
          display:'flex', flexDirection:'column',
          alignItems:'center', justifyContent:'center', gap:16,
          animation:'slideUp 0.5s ease',
        }}>
          <div style={{ fontSize:80, animation:'float 2s infinite' }}>🤟</div>
          <div style={{ fontFamily:"'Baloo 2',sans-serif", fontSize:32, fontWeight:800, textAlign:'center' }}>
            Bem-vindo ao<br/>
            <span style={{ background:'linear-gradient(90deg,#7B2FBE,#FF4D8D)', WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent' }}>
              LIBRAS Quest!
            </span>
          </div>
          <div style={{ color:'var(--muted)', fontSize:15 }}>Aprenda LIBRAS brincando</div>
        </div>
      )}

      {/* Screens */}
      {screen === 'home' && (
        <Home
          gameState={gameState}
          onSelectCategory={handleSelectCategory}
          onOpenProfile={() => setScreen('profile')}
        />
      )}

      {screen === 'quiz' && activeCategory && (
        <Quiz
          categoryId={activeCategory}
          gameState={gameState}
          onFinish={handleQuizFinish}
        />
      )}

      {screen === 'profile' && (
        <Profile
          gameState={gameState}
          onBack={() => setScreen('home')}
        />
      )}

      {/* Global overlays */}
      <BadgeToast badgeIds={newBadges} />
    </>
  )
}
