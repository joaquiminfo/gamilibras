import React, { useState, useEffect, useCallback } from 'react'
import { SIGNS, CATEGORIES } from '../data'
import Hearts from './Hearts'
import Confetti from './Confetti'

const FEEDBACK_MESSAGES_CORRECT = [
  'Incrível! 🎉', 'Perfeito! ✨', 'Arrasou! 🌟', 'Show! 🔥', 'Muito bem! 💪',
  'Ótimo! 🎊', 'Certo! 👏', 'Excelente! 🚀', 'Mandou bem! 🤩', 'Acertou! ⚡',
]
const FEEDBACK_MESSAGES_WRONG = [
  'Quase lá! 💪', 'Não desista! 🌱', 'Tente de novo! 🔄', 'Continue assim! 💡',
  'Você vai conseguir! 🎯',
]

export default function Quiz({ categoryId, gameState, onFinish }) {
  const signs = SIGNS[categoryId] || []
  const category = CATEGORIES.find(c => c.id === categoryId)
  const { hearts, loseHeart, addXP, completeLesson, updateCombo, currentCombo, setFastRound } = gameState

  const [queue, setQueue] = useState(() => shuffleArr([...signs]))
  const [current, setCurrent] = useState(0)
  const [selected, setSelected] = useState(null)
  const [feedback, setFeedback] = useState(null) // 'correct' | 'wrong'
  const [feedbackMsg, setFeedbackMsg] = useState('')
  const [score, setScore] = useState(0)
  const [mistakes, setMistakes] = useState(0)
  const [xpEarned, setXpEarned] = useState(0)
  const [showResult, setShowResult] = useState(false)
  const [showConfetti, setShowConfetti] = useState(false)
  const [startTime] = useState(Date.now())
  const [questionStart, setQuestionStart] = useState(Date.now())
  const [options, setOptions] = useState([])

  const sign = queue[current]

  useEffect(() => {
    if (!sign) return
    // Shuffle options for current question
    setOptions(shuffleArr([...sign.options]))
    setQuestionStart(Date.now())
  }, [current, sign])

  function shuffleArr(arr) {
    return arr.sort(() => Math.random() - 0.5)
  }

  function handleAnswer(opt) {
    if (feedback) return
    const correct = opt === sign.word
    setSelected(opt)
    setFeedback(correct ? 'correct' : 'wrong')

    if (correct) {
      const elapsed = (Date.now() - questionStart) / 1000
      const speedBonus = elapsed < 3 ? 5 : 0
      const comboBonus = currentCombo >= 4 ? 10 : currentCombo >= 2 ? 5 : 0
      const earned = (category?.xp || 10) + speedBonus + comboBonus
      setXpEarned(x => x + earned)
      setScore(s => s + 1)
      updateCombo(true)
      setFeedbackMsg(FEEDBACK_MESSAGES_CORRECT[Math.floor(Math.random() * FEEDBACK_MESSAGES_CORRECT.length)])

      // Check speed achievement (5 correct in first 30s)
      if (score + 1 >= 5 && (Date.now() - startTime) < 30000) {
        setFastRound()
      }
    } else {
      setMistakes(m => m + 1)
      loseHeart()
      updateCombo(false)
      setFeedbackMsg(FEEDBACK_MESSAGES_WRONG[Math.floor(Math.random() * FEEDBACK_MESSAGES_WRONG.length)])
    }

    setTimeout(() => {
      setFeedback(null)
      setSelected(null)
      if (current + 1 >= queue.length || (hearts <= 1 && !correct)) {
        finishLesson(correct ? score + 1 : score, correct ? xpEarned + (category?.xp || 10) : xpEarned)
      } else {
        setCurrent(c => c + 1)
      }
    }, 1200)
  }

  function finishLesson(finalScore, finalXP) {
    addXP(finalXP, categoryId)
    completeLesson(categoryId, mistakes === 0)
    const perfect = mistakes === 0
    if (perfect) setShowConfetti(true)
    setShowResult(true)
  }

  const progress = ((current) / queue.length) * 100

  if (showResult) {
    const perfect = mistakes === 0
    const stars = mistakes === 0 ? 3 : mistakes <= 2 ? 2 : 1
    return (
      <div style={{
        minHeight:'100vh', display:'flex', flexDirection:'column',
        alignItems:'center', justifyContent:'center',
        background:'var(--dark)', padding:24,
      }}>
        <Confetti active={showConfetti} />
        <div style={{
          background:'var(--card)', borderRadius:28, padding:'40px 32px',
          width:'100%', maxWidth:400, textAlign:'center',
          animation:'popIn 0.5s ease',
          border: perfect ? '2px solid #FFD93D' : '2px solid #243050',
          boxShadow: perfect ? '0 0 40px rgba(255,217,61,0.3)' : 'var(--shadow)',
        }}>
          <div style={{ fontSize:64, marginBottom:16, animation:'float 3s infinite' }}>
            {perfect ? '🏆' : stars === 2 ? '🎉' : '💪'}
          </div>

          {/* Stars */}
          <div style={{ display:'flex', justifyContent:'center', gap:8, marginBottom:20 }}>
            {[1,2,3].map(s => (
              <span key={s} style={{
                fontSize:36,
                filter: s <= stars ? 'none' : 'grayscale(1) opacity(0.3)',
                animation: s <= stars ? `starPop 0.5s ${s * 0.2}s both` : 'none',
              }}>⭐</span>
            ))}
          </div>

          <h2 style={{ fontFamily:"'Baloo 2',sans-serif", fontSize:24, fontWeight:800, marginBottom:6 }}>
            {perfect ? 'Perfeito!' : 'Lição Concluída!'}
          </h2>
          <p style={{ color:'var(--muted)', fontSize:14, marginBottom:28 }}>
            {category?.label} · {score}/{queue.length} acertos
          </p>

          {/* Stats */}
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10, marginBottom:24 }}>
            {[
              { label:'XP Ganho', value:`+${xpEarned}`, emoji:'⚡', color:'#FFD93D' },
              { label:'Acertos', value:score, emoji:'✅', color:'#06D6A0' },
              { label:'Erros', value:mistakes, emoji:'❌', color:'#EF233C' },
              { label:'Combo', value:currentCombo > 0 ? `x${currentCombo}` : '-', emoji:'🔥', color:'#FF6B35' },
            ].map(st => (
              <div key={st.label} style={{
                background:'#1A1A2E', borderRadius:14, padding:'12px 10px',
              }}>
                <div style={{ fontSize:20 }}>{st.emoji}</div>
                <div style={{ fontWeight:800, fontSize:20, color:st.color }}>{st.value}</div>
                <div style={{ fontSize:11, color:'var(--muted)' }}>{st.label}</div>
              </div>
            ))}
          </div>

          <div style={{ display:'flex', gap:10 }}>
            <button
              onClick={() => { setQueue(shuffleArr([...signs])); setCurrent(0); setScore(0); setMistakes(0); setXpEarned(0); setShowResult(false); setShowConfetti(false) }}
              style={{
                flex:1, background:'#1E2A45', border:'2px solid #243050',
                borderRadius:14, padding:'14px', color:'var(--text)',
                fontWeight:700, fontSize:15, cursor:'pointer', transition:'all 0.2s',
              }}
              onMouseEnter={e => e.currentTarget.style.borderColor = '#7B2FBE'}
              onMouseLeave={e => e.currentTarget.style.borderColor = '#243050'}
            >
              🔄 Repetir
            </button>
            <button
              onClick={onFinish}
              style={{
                flex:1,
                background:`linear-gradient(135deg, ${category?.color || '#7B2FBE'}, ${category?.color || '#7B2FBE'}aa)`,
                border:'none', borderRadius:14, padding:'14px',
                color:'#fff', fontWeight:800, fontSize:15,
                cursor:'pointer', transition:'all 0.2s',
                boxShadow:`0 4px 20px ${category?.color || '#7B2FBE'}50`,
              }}
              onMouseEnter={e => e.currentTarget.style.transform='translateY(-2px)'}
              onMouseLeave={e => e.currentTarget.style.transform='translateY(0)'}
            >
              ✅ Continuar
            </button>
          </div>
        </div>
      </div>
    )
  }

  if (!sign) return null

  return (
    <div style={{ minHeight:'100vh', background:'var(--dark)', display:'flex', flexDirection:'column' }}>
      {/* Header */}
      <div style={{
        padding:'16px 20px', display:'flex', alignItems:'center', gap:14,
        borderBottom:'1px solid #1E2A45',
      }}>
        <button onClick={onFinish} style={{
          background:'none', border:'none', color:'var(--muted)',
          fontSize:20, cursor:'pointer', padding:4, lineHeight:1,
        }}>✕</button>

        {/* Progress bar */}
        <div style={{ flex:1, height:10, background:'#1E2A45', borderRadius:99, overflow:'hidden' }}>
          <div style={{
            height:'100%', width:progress+'%',
            background:`linear-gradient(90deg, ${category?.color}, ${category?.color}cc)`,
            borderRadius:99, transition:'width 0.4s ease',
          }}/>
        </div>

        <Hearts count={hearts} max={5} />
      </div>

      {/* Combo banner */}
      {currentCombo >= 2 && (
        <div style={{
          background:`linear-gradient(90deg, #FF6B3520, #FF6B3510)`,
          borderBottom:'1px solid #FF6B3540',
          padding:'8px 20px', textAlign:'center',
          fontSize:13, fontWeight:700, color:'#FF6B35',
        }}>
          🔥 COMBO x{currentCombo}! +{currentCombo >= 4 ? 10 : 5} XP bônus
        </div>
      )}

      {/* Question */}
      <div style={{ flex:1, display:'flex', flexDirection:'column', alignItems:'center', padding:'32px 20px 20px', maxWidth:480, margin:'0 auto', width:'100%' }}>

        <div style={{ marginBottom:10, fontSize:12, fontWeight:700, color:'var(--muted)', letterSpacing:1 }}>
          {current + 1} / {queue.length} · {category?.label}
        </div>

        {/* Sign card */}
        <div style={{
          background: feedback === 'correct'
            ? 'linear-gradient(135deg, #06D6A010, #06D6A020)'
            : feedback === 'wrong'
              ? 'linear-gradient(135deg, #EF233C10, #EF233C20)'
              : 'var(--card)',
          border: feedback === 'correct'
            ? '3px solid #06D6A0'
            : feedback === 'wrong'
              ? '3px solid #EF233C'
              : '3px solid #243050',
          borderRadius:24, padding:'32px 24px',
          textAlign:'center', width:'100%', marginBottom:12,
          transition:'all 0.3s',
          animation: feedback === 'wrong' ? 'shake 0.4s ease' : feedback === 'correct' ? 'popIn 0.3s ease' : 'none',
        }}>
          <div style={{ fontSize:90, marginBottom:12, animation:'float 3s infinite' }}>
            {sign.sign}
          </div>
          <div style={{ fontSize:13, color:'var(--muted)', lineHeight:1.5 }}>{sign.desc}</div>
          {feedback && (
            <div style={{
              marginTop:12, fontSize:18, fontWeight:800,
              color: feedback === 'correct' ? '#06D6A0' : '#EF233C',
              animation:'popIn 0.3s ease',
            }}>
              {feedbackMsg}
            </div>
          )}
        </div>

        <p style={{ fontSize:15, fontWeight:700, color:'var(--text)', marginBottom:16, textAlign:'center' }}>
          Qual palavra este sinal representa?
        </p>

        {/* Options */}
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10, width:'100%' }}>
          {options.map((opt) => {
            const isSelected = selected === opt
            const isCorrect = opt === sign.word
            let bg = 'var(--card)'
            let border = '2px solid #243050'
            let color = 'var(--text)'

            if (isSelected) {
              if (feedback === 'correct') { bg='#06D6A020'; border='2px solid #06D6A0'; color='#06D6A0' }
              else { bg='#EF233C20'; border='2px solid #EF233C'; color='#EF233C' }
            } else if (feedback === 'wrong' && isCorrect) {
              bg='#06D6A010'; border='2px solid #06D6A080'; color='#06D6A0'
            }

            return (
              <button
                key={opt}
                onClick={() => handleAnswer(opt)}
                disabled={!!feedback}
                style={{
                  background: bg, border, borderRadius:16,
                  padding:'16px 12px', color, fontWeight:700,
                  fontSize:15, cursor: feedback ? 'default' : 'pointer',
                  transition:'all 0.15s',
                  textAlign:'center',
                }}
                onMouseEnter={e => { if (!feedback) e.currentTarget.style.borderColor='#7B2FBE' }}
                onMouseLeave={e => { if (!feedback) e.currentTarget.style.borderColor='#243050' }}
              >
                {opt}
              </button>
            )
          })}
        </div>
      </div>
    </div>
  )
}
