import React, { useEffect, useState } from 'react'
import { BADGES } from '../data'

export default function BadgeToast({ badgeIds }) {
  const [visible, setVisible] = useState(false)
  const [current, setCurrent] = useState(null)

  useEffect(() => {
    if (!badgeIds || badgeIds.length === 0) return
    const badge = BADGES.find(b => b.id === badgeIds[0])
    if (!badge) return
    setCurrent(badge)
    setVisible(true)
    const t = setTimeout(() => setVisible(false), 3500)
    return () => clearTimeout(t)
  }, [badgeIds])

  if (!visible || !current) return null

  return (
    <div style={{
      position:'fixed', bottom:32, left:'50%', transform:'translateX(-50%)',
      background:'linear-gradient(135deg, #1E2A45, #243050)',
      border:'2px solid #FFD93D',
      borderRadius:20, padding:'16px 24px',
      display:'flex', alignItems:'center', gap:14,
      boxShadow:'0 8px 40px rgba(0,0,0,0.5)',
      zIndex:9000, animation:'slideUp 0.4s ease',
      minWidth:280,
    }}>
      <span style={{ fontSize:36 }}>{current.emoji}</span>
      <div>
        <div style={{ fontSize:11, color:'#FFD93D', fontWeight:700, letterSpacing:1 }}>BADGE DESBLOQUEADA!</div>
        <div style={{ fontSize:16, fontWeight:800, color:'#F0F4FF' }}>{current.label}</div>
        <div style={{ fontSize:12, color:'#8892AA' }}>{current.desc}</div>
      </div>
    </div>
  )
}
