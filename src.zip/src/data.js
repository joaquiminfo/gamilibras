// Dados completos de LIBRAS com emojis representando os sinais
// Em produção, substituir os emojis por imagens/GIFs reais dos sinais

export const CATEGORIES = [
  { id: 'abc',      label: 'Alfabeto',     emoji: '🔤', color: '#7B2FBE', xp: 10 },
  { id: 'numeros',  label: 'Números',      emoji: '🔢', color: '#118AB2', xp: 10 },
  { id: 'cumprimentos', label: 'Cumprimentos', emoji: '👋', color: '#06D6A0', xp: 15 },
  { id: 'familia',  label: 'Família',      emoji: '👨‍👩‍👧', color: '#FF6B35', xp: 15 },
  { id: 'cores',    label: 'Cores',        emoji: '🎨', color: '#FF4D8D', xp: 15 },
  { id: 'animais',  label: 'Animais',      emoji: '🐾', color: '#FFD93D', xp: 20 },
  { id: 'comida',   label: 'Comida',       emoji: '🍎', color: '#EF233C', xp: 20 },
  { id: 'emocoes',  label: 'Emoções',      emoji: '😊', color: '#06D6A0', xp: 20 },
]

export const SIGNS = {
  abc: [
    { id:'a1', word:'A', sign:'👆', desc:'Punho fechado, polegar ao lado', options:['A','E','I','O'] },
    { id:'a2', word:'B', sign:'✋', desc:'Mão aberta, dedos juntos, polegar dobrado', options:['B','D','G','P'] },
    { id:'a3', word:'C', sign:'🤏', desc:'Dedos curvados formando a letra C', options:['C','G','O','Q'] },
    { id:'a4', word:'D', sign:'☝️', desc:'Indicador levantado, outros curvados', options:['D','B','F','L'] },
    { id:'a5', word:'E', sign:'🤙', desc:'Dedos dobrados, polegar e mindinho estendidos', options:['E','A','I','U'] },
    { id:'a6', word:'L', sign:'🤞', desc:'Polegar e indicador em L', options:['L','V','Y','D'] },
    { id:'a7', word:'O', sign:'👌', desc:'Dedos formando um círculo', options:['O','C','Q','G'] },
    { id:'a8', word:'V', sign:'✌️', desc:'Indicador e médio estendidos em V', options:['V','L','Y','K'] },
  ],
  numeros: [
    { id:'n1', word:'1', sign:'☝️', desc:'Indicador levantado', options:['1','2','3','5'] },
    { id:'n2', word:'2', sign:'✌️', desc:'Indicador e médio levantados', options:['2','1','3','4'] },
    { id:'n3', word:'3', sign:'🤟', desc:'Polegar, indicador e médio levantados', options:['3','5','7','8'] },
    { id:'n4', word:'4', sign:'🖖', desc:'Quatro dedos estendidos', options:['4','3','5','6'] },
    { id:'n5', word:'5', sign:'🖐️', desc:'Mão aberta, cinco dedos', options:['5','4','6','8'] },
    { id:'n6', word:'6', sign:'🤙', desc:'Polegar e mindinho estendidos', options:['6','7','8','9'] },
    { id:'n7', word:'7', sign:'👇', desc:'Indicador apontando para baixo', options:['7','6','8','9'] },
    { id:'n8', word:'8', sign:'🤌', desc:'Dedos pinçados', options:['8','6','7','9'] },
    { id:'n9', word:'9', sign:'👌', desc:'Indicador e polegar em O', options:['9','6','7','8'] },
    { id:'n10', word:'10', sign:'🤘', desc:'Mão balançando', options:['10','5','6','9'] },
  ],
  cumprimentos: [
    { id:'c1', word:'Oi / Olá', sign:'👋', desc:'Mão aberta balançando lateralmente', options:['Oi / Olá','Tchau','Obrigado','Com licença'] },
    { id:'c2', word:'Tchau', sign:'🤚', desc:'Mão aberta, dedos juntos, balançando', options:['Tchau','Oi / Olá','Até logo','Volte sempre'] },
    { id:'c3', word:'Obrigado', sign:'🙏', desc:'Mão na boca, movimento para frente', options:['Obrigado','De nada','Por favor','Desculpa'] },
    { id:'c4', word:'De nada', sign:'👐', desc:'Mãos abertas, movimento para os lados', options:['De nada','Obrigado','Por favor','Com licença'] },
    { id:'c5', word:'Por favor', sign:'🤲', desc:'Palmas unidas, inclinação da cabeça', options:['Por favor','Obrigado','De nada','Desculpa'] },
    { id:'c6', word:'Bom dia', sign:'🌅', desc:'Mão na testa, movimento para cima', options:['Bom dia','Boa tarde','Boa noite','Olá'] },
    { id:'c7', word:'Boa noite', sign:'🌙', desc:'Mão na testa, movimento para baixo', options:['Boa noite','Bom dia','Boa tarde','Até logo'] },
    { id:'c8', word:'Tudo bem?', sign:'👍', desc:'Polegar levantado com expressão interrogativa', options:['Tudo bem?','Como vai?','O que há?','Olá'] },
  ],
  familia: [
    { id:'f1', word:'Mãe', sign:'👩', desc:'Mão em M, na bochecha', options:['Mãe','Pai','Vovó','Tia'] },
    { id:'f2', word:'Pai', sign:'👨', desc:'Mão em P, na testa', options:['Pai','Mãe','Vovô','Tio'] },
    { id:'f3', word:'Irmão', sign:'🧑', desc:'Dois indicadores unidos lado a lado', options:['Irmão','Irmã','Primo','Amigo'] },
    { id:'f4', word:'Irmã', sign:'👧', desc:'Dois indicadores, movimento de baixo para cima', options:['Irmã','Irmão','Prima','Amiga'] },
    { id:'f5', word:'Avó', sign:'👵', desc:'Mão em A, no queixo, movimento para baixo', options:['Avó','Mãe','Tia','Bisavó'] },
    { id:'f6', word:'Avô', sign:'👴', desc:'Mão em A, na testa, movimento para baixo', options:['Avô','Pai','Tio','Bisavô'] },
    { id:'f7', word:'Filho', sign:'👦', desc:'Mão em F, balanceada como bebê', options:['Filho','Filha','Sobrinho','Primo'] },
    { id:'f8', word:'Filha', sign:'👧', desc:'Mão em F, balanceada, expressão afetiva', options:['Filha','Filho','Sobrinha','Prima'] },
  ],
  cores: [
    { id:'cor1', word:'Vermelho', sign:'🔴', desc:'Indicador nos lábios, movimento para baixo', options:['Vermelho','Azul','Verde','Amarelo'] },
    { id:'cor2', word:'Azul', sign:'🔵', desc:'Mão em A, movimento circular', options:['Azul','Verde','Roxo','Vermelho'] },
    { id:'cor3', word:'Verde', sign:'🟢', desc:'Mão em V, movimento de torção', options:['Verde','Azul','Amarelo','Laranja'] },
    { id:'cor4', word:'Amarelo', sign:'🟡', desc:'Mão em Y, movimento lateral', options:['Amarelo','Verde','Laranja','Dourado'] },
    { id:'cor5', word:'Preto', sign:'⚫', desc:'Indicador na sobrancelha, movement lateral', options:['Preto','Cinza','Marrom','Escuro'] },
    { id:'cor6', word:'Branco', sign:'⚪', desc:'Mão no peito, movimento para frente', options:['Branco','Cinza','Claro','Rosa'] },
    { id:'cor7', word:'Rosa', sign:'🩷', desc:'Indicador no nariz, movimento para baixo', options:['Rosa','Vermelho','Lilás','Magenta'] },
    { id:'cor8', word:'Laranja', sign:'🟠', desc:'Mão em C, abrindo e fechando', options:['Laranja','Amarelo','Vermelho','Marrom'] },
  ],
  animais: [
    { id:'an1', word:'Cachorro', sign:'🐕', desc:'Estalar dedos na coxa, chamar o cão', options:['Cachorro','Gato','Coelho','Lobo'] },
    { id:'an2', word:'Gato', sign:'🐱', desc:'Dedos como bigodes de felino', options:['Gato','Cachorro','Tigre','Leão'] },
    { id:'an3', word:'Pássaro', sign:'🐦', desc:'Polegar e indicador no bico, abrindo e fechando', options:['Pássaro','Peixe','Borboleta','Sapo'] },
    { id:'an4', word:'Peixe', sign:'🐟', desc:'Mão plana, movimento ondulante', options:['Peixe','Cobra','Tartaruga','Golfinho'] },
    { id:'an5', word:'Coelho', sign:'🐰', desc:'Dois dedos apontados para cima como orelhas', options:['Coelho','Cachorro','Gato','Rato'] },
    { id:'an6', word:'Elefante', sign:'🐘', desc:'Mão curvada na frente do nariz (tromba)', options:['Elefante','Hipopótamo','Rinoceronte','Girafa'] },
    { id:'an7', word:'Borboleta', sign:'🦋', desc:'Mãos entrelaçadas, dedos como asas', options:['Borboleta','Abelha','Libélula','Mariposa'] },
    { id:'an8', word:'Leão', sign:'🦁', desc:'Mãos em garra, movimento para frente', options:['Leão','Tigre','Onça','Leopardo'] },
  ],
  comida: [
    { id:'co1', word:'Água', sign:'💧', desc:'Mão em W, tocar os lábios', options:['Água','Suco','Leite','Café'] },
    { id:'co2', word:'Pão', sign:'🍞', desc:'Mão em P, cortar na palma oposta', options:['Pão','Bolo','Biscoito','Torrada'] },
    { id:'co3', word:'Fruta', sign:'🍎', desc:'Mão em F, morder o indicador dobrado', options:['Fruta','Legume','Verdura','Semente'] },
    { id:'co4', word:'Leite', sign:'🥛', desc:'Apertar mão como ordenhar', options:['Leite','Água','Suco','Iogurte'] },
    { id:'co5', word:'Arroz', sign:'🍚', desc:'Dedos indicadores paralelos, movimento lateral', options:['Arroz','Feijão','Macarrão','Milho'] },
    { id:'co6', word:'Feijão', sign:'🫘', desc:'Dedos pressionados como grão', options:['Feijão','Arroz','Lentilha','Grão'] },
    { id:'co7', word:'Bolo', sign:'🎂', desc:'Mão em B, mover para cima como vela', options:['Bolo','Torta','Pudim','Sorvete'] },
    { id:'co8', word:'Café', sign:'☕', desc:'Mão em C, tomar da xícara', options:['Café','Chá','Leite','Chocolate'] },
  ],
  emocoes: [
    { id:'em1', word:'Feliz', sign:'😊', desc:'Mãos no peito, movimento circular para cima', options:['Feliz','Triste','Bravo','Assustado'] },
    { id:'em2', word:'Triste', sign:'😢', desc:'Dedos descendo pelo rosto como lágrimas', options:['Triste','Feliz','Entediado','Frustrado'] },
    { id:'em3', word:'Amor', sign:'❤️', desc:'Mão cruzada no peito, expressão afetiva', options:['Amor','Carinho','Amizade','Saudade'] },
    { id:'em4', word:'Bravo', sign:'😠', desc:'Punhos cerrados, expressão de raiva', options:['Bravo','Feliz','Frustrado','Nervoso'] },
    { id:'em5', word:'Com medo', sign:'😨', desc:'Mãos tremendo na frente do peito', options:['Com medo','Surpreso','Nervoso','Assustado'] },
    { id:'em6', word:'Surpreso', sign:'😲', desc:'Mãos abrindo na frente do rosto', options:['Surpreso','Com medo','Impressionado','Incrédulo'] },
    { id:'em7', word:'Cansado', sign:'😴', desc:'Mãos caindo, cabeça inclinada', options:['Cansado','Sonolento','Preguiçoso','Relaxado'] },
    { id:'em8', word:'Saudade', sign:'🥺', desc:'Mão no peito, movimento circular', options:['Saudade','Amor','Carinho','Tristeza'] },
  ],
}

export const BADGES = [
  { id: 'first_step',  label: 'Primeiro Passo',   emoji: '👣', desc: 'Complete sua primeira lição', condition: s => s.totalLessons >= 1 },
  { id: 'abc_master',  label: 'Mestre do ABC',     emoji: '🔤', desc: 'Complete o Alfabeto', condition: s => s.completedCategories.includes('abc') },
  { id: 'streak3',     label: 'Em Chamas 🔥',      emoji: '🔥', desc: '3 dias seguidos', condition: s => s.streak >= 3 },
  { id: 'streak7',     label: 'Uma Semana!',       emoji: '🌟', desc: '7 dias seguidos', condition: s => s.streak >= 7 },
  { id: 'perfect',     label: 'Perfeito!',         emoji: '💯', desc: 'Acerte 10 questões seguidas', condition: s => s.maxCombo >= 10 },
  { id: 'xp500',       label: '500 XP',            emoji: '⚡', desc: 'Acumule 500 XP', condition: s => s.totalXP >= 500 },
  { id: 'xp1000',      label: 'Guerreiro LIBRAS',  emoji: '🏆', desc: 'Acumule 1000 XP', condition: s => s.totalXP >= 1000 },
  { id: 'allcats',     label: 'Explorador',        emoji: '🗺️', desc: 'Tente todas as categorias', condition: s => s.triedCategories.length >= 8 },
  { id: 'speed',       label: 'Velocidade!',       emoji: '⚡', desc: 'Acerte 5 em menos de 30s', condition: s => s.fastRound === true },
  { id: 'comeback',    label: 'Virada!',           emoji: '💪', desc: 'Acerte após 3 erros seguidos', condition: s => s.comeback === true },
]

export const LEVELS = [
  { level:1,  label:'Aprendiz',    min:0,    max:100,   color:'#8892AA' },
  { level:2,  label:'Estudante',   min:100,  max:250,   color:'#06D6A0' },
  { level:3,  label:'Praticante',  min:250,  max:500,   color:'#118AB2' },
  { level:4,  label:'Intérprete',  min:500,  max:900,   color:'#7B2FBE' },
  { level:5,  label:'Comunicador', min:900,  max:1500,  color:'#FF6B35' },
  { level:6,  label:'Fluente',     min:1500, max:2500,  color:'#FFD93D' },
  { level:7,  label:'Mestre',      min:2500, max:99999, color:'#FF4D8D' },
]

export function getLevel(xp) {
  return LEVELS.find(l => xp >= l.min && xp < l.max) || LEVELS[LEVELS.length - 1]
}

export function getXPForNext(xp) {
  const lvl = getLevel(xp)
  return ((xp - lvl.min) / (lvl.max - lvl.min)) * 100
}
